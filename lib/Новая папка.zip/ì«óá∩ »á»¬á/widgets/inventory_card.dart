import 'package:flutter/material.dart';
import 'models/inventory_model.dart';

class InventoryCard extends StatelessWidget {
  final Inventory inventory;
  final Function(Inventory) onAddToCart;

  InventoryCard({required this.inventory, required this.onAddToCart});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        leading: Image.network(inventory.imageUrl),
        title: Text(inventory.name),
        subtitle: Text('Цена: \$${inventory.pricePerDay}'),
        trailing: ElevatedButton(
          onPressed: () {
            onAddToCart(inventory);
          },
          child: Text('Добавить в корзину'),
        ),
      ),
    );
  }
}