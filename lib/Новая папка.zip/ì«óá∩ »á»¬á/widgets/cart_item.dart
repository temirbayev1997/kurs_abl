import 'package:flutter/material.dart';

class CartItem extends StatelessWidget {
  final String name;
  final double price;
  final int quantity;

  CartItem({required this.name, required this.price, required this.quantity});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        title: Text(name),
        subtitle: Text('Цена: \$${price.toStringAsFixed(2)}'),
        trailing: Text('Количество: $quantity'),
      ),
    );
  }
}