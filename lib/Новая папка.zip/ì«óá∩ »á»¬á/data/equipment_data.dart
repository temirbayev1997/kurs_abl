import '../models/equipment.dart';

final List<Equipment> equipmentList = [
  Equipment(
    id: '1',
    name: 'Баскетбольный мяч',
    description: 'Профессиональный мяч для игры в баскетбол.',
    pricePerHour: 5.0,
    imageUrl: 'https://example.com/basketball.jpg',
  ),
  Equipment(
    id: '2',
    name: 'Футбольный мяч',
    description: 'Качественный мяч для футбола.',
    pricePerHour: 4.0,
    imageUrl: 'https://example.com/football.jpg',
  ),
  Equipment(
    id: '3',
    name: 'Теннисная ракетка',
    description: 'Легкая и удобная ракетка для тенниса.',
    pricePerHour: 7.0,
    imageUrl: 'https://example.com/tennis.jpg',
  ),
];
