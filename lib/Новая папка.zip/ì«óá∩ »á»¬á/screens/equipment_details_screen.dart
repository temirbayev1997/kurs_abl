import 'package:flutter/material.dart';
import '../models/equipment.dart';

class EquipmentDetailsScreen extends StatelessWidget {
  final Equipment equipment;

  const EquipmentDetailsScreen({Key? key, required this.equipment}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(equipment.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(equipment.imageUrl, height: 200, fit: BoxFit.cover),
            SizedBox(height: 16),
            Text(
              equipment.name,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              equipment.description,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Text(
              'Цена: \$${equipment.pricePerHour}/час',
              style: TextStyle(fontSize: 20, color: Colors.green),
            ),
            Spacer(),
            ElevatedButton(
              onPressed: () {
                // Реализация аренды
              },
              child: Text('Арендовать'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
