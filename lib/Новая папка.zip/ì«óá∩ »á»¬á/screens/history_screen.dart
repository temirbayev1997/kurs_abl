import 'package:flutter/material.dart';
import 'models/rental_model.dart';

class HistoryScreen extends StatelessWidget {
  final List<Rental> rentalList = [
    // Пример данных
    Rental(
      id: '1',
      inventoryId: '1',
      startDate: DateTime.now(),
      endDate: DateTime.now().add(Duration(days: 7)),
      totalCost: 70.0,
    ),
  ];

  @override
  Widget build(BuildContext context ```dart
    ) {
    return Scaffold(
      appBar: AppBar(
        title: Text('История аренды'),
      ),
      body: ListView.builder(
        itemCount: rentalList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('Аренда инвентаря ID: ${rentalList[index].inventoryId}'),
            subtitle: Text('С ${rentalList[index].startDate} по ${rentalList[index].endDate}'),
            trailing: Text('Итого: ${rentalList[index].totalCost}'),
          );
        },
      ),
    );
  }
}