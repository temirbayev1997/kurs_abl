import 'package:flutter/material.dart';
import 'cart_screen.dart'; // Исправленный путь
import '../widgets/search_bar.dart'; // Исправленный путь
import '../widgets/inventory_card.dart'; // Исправленный путь
import '../models/inventory_model.dart'; // Исправленный путь

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Inventory> inventoryList = [
    // Пример данных
    Inventory(
      id: '1',
      name: 'Велосипед',
      description: 'Горный велосипед',
      imageUrl: 'https://example.com/bike.jpg',
      pricePerDay: 10.0,
      rating: 4.5,
      isAvailable: true,
    ),
  ];

  List<Map<String, dynamic>> cartItems = [];

  void _addToCart(Inventory inventory) {
    setState(() {
      cartItems.add({
        'name': inventory.name,
        'price': inventory.pricePerDay,
        'quantity': 1,
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sport Rent'),
      ),
      body: Column(
        children: [
          SearchBar(),
          Expanded(
            child: ListView.builder(
              itemCount: inventoryList.length,
              itemBuilder: (context, index) {
                return InventoryCard(
                  inventory: inventoryList[index],
                  onAddToCart: _addToCart,
                );
              },
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CartScreen(cartItems: cartItems)),
              );
            },
            child: Text('Перейти в корзину'),
          ),
        ],
      ),
    );
  }
}