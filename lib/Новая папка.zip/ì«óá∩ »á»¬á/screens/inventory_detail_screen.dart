import 'package:flutter/material.dart';
import 'models/inventory_model.dart';
import 'widgets/rating_stars.dart';

class InventoryDetailScreen extends StatelessWidget {
  final Inventory inventory;

  InventoryDetailScreen({required this.inventory});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(inventory.name),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.network(inventory.imageUrl),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(inventory.description),
            ),
            Text('Цена: ${inventory.pricePerDay} в день'),
            RatingStars(rating: inventory.rating),
            ElevatedButton(
              onPressed: () {
                // Логика аренды инвентаря
              },
              child: Text('Арендовать'),
            ),
          ],
        ),
      ),
    );
  }
}