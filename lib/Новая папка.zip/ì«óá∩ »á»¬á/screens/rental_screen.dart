import 'package:flutter/material.dart';
import 'widgets/calendar_picker.dart';

class RentalScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Аренда инвентаря'),
      ),
      body: Column(
        children: [
          CalendarPicker(),
          ElevatedButton(
            onPressed: () {
              // Логика оплаты аренды
            },
            child: Text('Оплатить аренду'),
          ),
        ],
      ),
    );
  }
}