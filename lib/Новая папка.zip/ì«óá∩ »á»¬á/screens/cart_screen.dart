import 'package:flutter/material.dart';
import '../widgets/cart_item.dart'; // Исправленный путь
import '../services/payment_service.dart'; // Исправленный путь
import '../../models/inventory_model.dart'; // Исправленный путь

class CartScreen extends StatefulWidget {
  final List<Map<String, dynamic>> cartItems;

  CartScreen({required this.cartItems});

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  double get totalPrice {
    return widget.cartItems.fold(0, (sum, item) => sum + (item['price'] * item['quantity']));
  }

  Future<void> _processPayment() async {
    try {
      await PaymentService.processPayment(totalPrice);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => PaymentSuccessScreen()),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка оплаты: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Корзина'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: widget.cartItems.length,
              itemBuilder: (context, index) {
                return CartItem(
                  name: widget.cartItems[index]['name'],
                  price: widget.cartItems[index]['price'],
                  quantity: widget.cartItems[index]['quantity'],
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Итого: \$${totalPrice.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          ElevatedButton(
            onPressed: _processPayment,
            child: Text('Оплатить'),
          ),
        ],
      ),
    );
  }
}