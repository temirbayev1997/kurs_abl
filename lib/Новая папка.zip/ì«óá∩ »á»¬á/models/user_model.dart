class User {
  String id;
  String name;
  int loyaltyPoints;

  User({required this.id, required this.name, this.loyaltyPoints = 0});

  void addLoyaltyPoints(int points) {
    loyaltyPoints += points;
  }

  void redeemLoyaltyPoints(int points) {
    if (loyaltyPoints >= points) {
      loyaltyPoints -= points;
    } else {
      throw Exception('Недостаточно баллов для погашения');
    }
  }
}