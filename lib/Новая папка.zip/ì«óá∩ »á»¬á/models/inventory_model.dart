class Inventory {
  final String id;
  final String name;
  final String description;
  final String imageUrl;
  final double pricePerDay;
  final double rating;
  final bool isAvailable;

  Inventory({
    required this.id,
    required this.name,
    required this.description,
    required this.imageUrl,
    required this.pricePerDay,
    required this.rating,
    required this.isAvailable,
  });
}