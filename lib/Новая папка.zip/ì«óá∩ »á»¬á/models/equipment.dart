class Equipment {
  final String id;
  final String name;
  final String description;
  final double pricePerHour;
  final String imageUrl;

  Equipment({
    required this.id,
    required this.name,
    required this.description,
    required this.pricePerHour,
    required this.imageUrl,
  });
}
