class Rental {
  final String id;
  final String inventoryId;
  final DateTime startDate;
  final DateTime endDate;
  final double totalCost;

  Rental({
    required this.id,
    required this.inventoryId,
    required this.startDate,
    required this.endDate,
    required this.totalCost,
  });
}