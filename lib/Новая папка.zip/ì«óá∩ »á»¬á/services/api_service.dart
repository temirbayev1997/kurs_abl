// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import '../models/inventory_model.dart';

// class ApiService {
//   final String baseUrl = 'https://api.example.com/inventory';

//   Future<List<Inventory>> fetchInventory() async {
//     final response = await http.get(Uri.parse(baseUrl));
//     if (response.statusCode == 200) {
//       List jsonResponse = json.decode(response.body);
//       return jsonResponse.map((data) => Inventory.fromJson(data)).toList();
//     } else {
//       throw Exception('Ошибка загрузки инвентаря');
//     }
//   }
// }