const String apiUrl = 'https://api.example.com';
const String appName = 'Sport Rent';